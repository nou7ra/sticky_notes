import mongoose from "mongoose";

const checkConnection = async () => {
  try {
    await mongoose.connect("mongodb://127.0.0.1:27017/sticky_notes ");
    console.log("DB connected successfully");
  } catch (error) {
    console.log("DB Failed to connect");
  }
};
export default checkConnection;
