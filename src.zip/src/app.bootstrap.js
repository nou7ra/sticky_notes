import express from "express";
import checkConnection from "./DB/connectionDB.js";
import userRouter from "./modules/userModule/user.controller.js";
import cors from "cors"
import checkConnection_redis, { redis_client } from "./DB/connectionRedis.js";
const app = express();
const port = 3000;

const bootstrap = async () => {
  app.use(cors())
  app.use(express.json());
  await checkConnection();
  await checkConnection_redis()
  

  app.use("/users", userRouter);
  app.get("/", (req, res) => res.send("Hello World!"));
  app.use("{/*demo}", (req, res, next) => {
    throw new Error(
      ` URL ${req.originalUrl} with Method ${req.method} not Found`,
      { cause: 404 },
    );
  });

  app.use((err, rq, res, next) => {
    res.status(err.cause || 500).json({
      message: err.message,
      statusCode: err.cause,
      stack: err.stack,
    });
  });
  app.listen(port, () => console.log(`Example app listening on port ${port}!`));
};
export default bootstrap;
